


<?php
   $resultado = $_GET['numero1'] + $_GET['numero2'];
   echo "O resutado da soma é $resultado";