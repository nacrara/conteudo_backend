<?php

$p1 = [
    "nome" => "Bolsa Feminina Quadrada Média Tradicional",
    "foto" => "https://m.media-amazon.com/images/I/91ja8iyicjL._AC_SX425_.jpg",
    "preco" => 159.99,
    "descricao" => "Confeccionada em material sintético de poliuretano com shape tradicional, seu design é quadrado e amplo, as alças curtas são perfeitas para usar na mão, já sua alça longa tiracolo removível se adapta bem transpassada ao corpo.",
    "categoria" => "Moda"
];

$p2 = [
    "nome" => "Nintendo, Console, Nintendo Switch, Nacional, V2, Portátil e Doméstico,
    Bateria de até 9 Horas, Inclui Joy-Con com Suporte e Alças, 1 ano de Garantia, Azul Neon e Vermelho Neon",
    "foto" => "https://m.media-amazon.com/images/I/71s9BjamD+L._AC_SX342_SY445_.jpg",
    "preco" => 50.00,
    "descrição" => "Sobre este item     JOGUE COMO PREFERIR. O Nintendo Switch foi desenvolvido para fazer parte da sua vida, transformando-se de um console doméstico em um console portátil num piscar de olhos     MODO TV. Coloque o seu Nintendo Switch na base do console para se divertir jogando em sua televisão.     MODO SEMIPORTÁTIL. Abra o suporte para compartilhar a tela do seu Nintendo Switch – e a diversão – em jogos multijogador.     MODO PORTÁTIL. Remova o console da base e jogue com os controles joy-con encaixados para aproveitar a diversão do seu Nintendo, de onde estiver.     ADAPTE-SE À DIVERSÃO. Os controles joy-con incluídos com o seu Nintendo Switch permitem total flexibilidade nos jogos.",
    "categoria" => "consoles",

];

$p3 = [
    "nome" => "O Voo do Corvo (Graphic Novel Volume Único) Capa dura – 23 abril 2023",
    "foto" => "https://m.media-amazon.com/images/I/51Ga6te+LuL._SY344_BO1,204,203,200_.jpg",
    "preco" => 76,
    "descricao" => "O premiado autor do fantástico Destino Adiado está de volta ao Brasil, desta vez com a graphic novel que foi considerada uma das mais belas do século XXI: O Voo do Cor",
    "categoria" => "Livros"
 ];

 $p4=[
    "nome"=>"Bolsa Feminina Transversal Tiracolo Com Alça Original",
    "foto"=>"https://http2.mlstatic.com/D_NQ_NP_2X_673869-MLB54337661221_032023-F.webp",
    "preco"=>74.93,
    "descricao"=>"BOLSA VIZZANO MATELASSÊ LINDA!!!    PRODUTO ORIGINAL E COM NOTA FISCAL!        APROVEITE ESSA CONDIÇÃO ESPECIAL!!!        Linda Bolsa da Vizzano, muito versátil, pode ser usada tanto transversal como tiracolo, possuí regulagem na alça, muito leve e se encaixa bem com qualquer look.     Excelente para todas ocasiões, dia a dia, shopping, barzinho, balada, parques e onde você quiser ela vai te acompanhar bem.        EXPECIFICAÇÕES    Marca: Vizzano    Composição: Napa Sardenha Neo (sintético)    Bolsos: 1    Fecho: Zíper metal dourado    Alça: Na cor da bolsa e ajustável    Material interno: Têxtil    Garantia da fábrica sobre defeitos        MEDIDAS    Comprimento: 20cm    Largura: 21cm    Profundidade (base): 4cm    Alça: 120cm        INTENS INCLUSOS    1x Bolsa Vizzano 10000.4        OBS.: Selecione a cor no momento da compra. (Não conseguimos alterar depois que a compra for fechada)        A Digos Online é uma loja com mais de 12 anos no mercado atuando com lojas físicas e agora quer trazer toda a qualidade de atendimento e excelente serviço aos consumidores online.",    
    "categoria"=>"Moda"
 ];

$p5=[
      "nome"=>"A dança do universo: Dos Mitos de Criação ao Big-Bang",
      "foto"=>"https://m.media-amazon.com/images/P/B009WWEOMC.01._SCLZZZZZZZ_SX500_.jpg",
      "preco"=>11.96,
      "descricao"=>"O que aconteceu no momento da Criação? Houve um minuto determinado em que o Universo que nos rodeia surgiu? Essas são questões tão antigas como a própria humanidade. Muitos procuram a resposta nos mitos e na religião. Outros nas teorias científicas. Em A dança do Universo, o físico Marcelo Gleiser mostra em linguagem clara que esses dois enfoques não são tão distantes quanto imaginamos, apresentando versões de diversas culturas para o mistério da Criação, até desembocar na explicação da ciência moderna para o surgimento do Universo.
      Prêmio Jabuti 1998 de Melhor Ensaio e Biografia",
      "categoria"=>"Livros" 
  ];


 $p6 = [
    "nome" => "2 peças Sapatos para animais de estimação Aleatória Escavar",
    "foto" => "https://img.ltwebstatic.com/images3_pi/2022/08/15/1660528339df32c60f5ecbf9f87ff1883657c336a8_thumbnail_600x.webp",
    "preco" => 22.95,
    "descricao" => "Cor:	Multicolorido     Estampa:	Simples     Material:	Plástico     Ideal para:	Gato / Cachorro.",
    "categoria" => "Moda"
 ];

 $p7 = [
    "nome" => "Arno Cafeteira Espresso Nescafé Dolce Gusto Genio S Plus DGS2, Preta",
    "foto" => "https://m.media-amazon.com/images/I/51r4SQJwwEL._AC_SY450_.jpg",
    "preco" => 517.54,
    "descricao" => "É multi-bebidas    Função XL: prepare um extra longo com +30ml de bebida com um só clique.     Função limpeza: Avisa a hora de limpar vestígios de café, leite e chocolate das partes internas garantindo que sua máquina fique sempre em excelentes condições e dure por muito mais tempo.     A NESCAFÉ Dolce Gusto Genio S possui reservatório de água com grande capacidade e função ECO.     4 ajustes de tempertura Espresso boost - Pré umidece seu espresso antes do preparo, café + concentrado! Anel de controle - Ajuste do tamanho da bebida.",
    "categoria" => "Eletrodoméstico"
 ];

 $p8 = [
    "nome" => "100% Pure Whey - 1800g Refil Chocolate - Probiotica",
    "foto" => "https://m.media-amazon.com/images/I/519FazUSFeL.__AC_SX300_SY300_QL70_ML2_.jpg",
    "preco" => 207.80,
    "descricao" => "<ul>Recuperação muscular; Previne o catabolismo; Proporciona mais força; Mais resistência</ul>",
    "categoria" => "Suplementos"
 ];

 $p9 = [
    "nome" => "Notebook Ideapad Gaming 3i I5 16gb 512gb Ssd Rtx 3050 Linux",
    "foto" => "https://http2.mlstatic.com/D_NQ_NP_662878-MLB52799977775_122022-O.webp",
    "preco" => 5.149,
    "descricao" => "Lenovo ideapad Gaming 3i: Novo design com 11ª Geração de Processadores Intel® Core™ i5-11300H e placa de vídeo NVIDIA® GeForce® RTX 3050 4GB. Ideal para gamers e usuários que também precisam de alta performance. Com tela de 15.6'' Full HD WVA Antirreflexo para melhor definição de imagem e cores. O armanezamento SSD PCIe NVMe é 10x mais rápido* que um HDD 2.5” SATA, você terá mais segurança ao armazenar seus dados. O teclado retroiluminado em LED branco, deixa o computador mais atraente e também favorece a performance para jogos em lugares com pouca iluminação. Silencioso e não esquenta: projetado com um sistema de resfriamento otimizado composto por 2 coolers e 4 saídas de ar para suportar o alto desempenho do notebook. Sua privacidade pessoal é muito importante. É por isso que o Ideapad Gaming 3i está equipado com prática porta de privacidade da webcam. Quando não estiver em uma chamada de vídeo ou gravando algo, basta deslizá-la. Nitidez e alta qualidade de som. Possui tecnologia de carregamento rápido: quinze minutos de carregamento garante até duas horas de uso**. A Lenovo coloca o Ideapad Gaming 3i à prova em testes de resistência altamente estressantes como: altas e baixas temperaturas, choque de temperatura, quebra e vibração, certificando a preocupação com a segurança e qualidade. Por meio de testes militares, mantém a convicção da melhor escolha sempre. A distância entre a tecla e o botão ficou menor: apenas 1.5mm. Tenha mais agilidade, rapidez e tempo de resposta. A função Smart Control permite que o usuário da Lenovo mude a engrenagem simplesmente pressionando as teclas Fn + Q. Mude do Modo Performance para maior FPS, altere do Modo Silencioso para melhor duração da bateria, ou use o Modo Balanceado para uso diário. Armazenamento híbrido: Possui 2 slots SSD M.2 e 1 slot HDD SATA.     *Com base na velocidade de leitura dos dados obtidos através de spec de dados de leitura mb/s.     ** Carregamento com o notebook desligado. A duração de bateria e o tempo de carregamento podem variar de acordo com o uso,      a configuração e outros fatores. Os resultados reais podem variar.",
    "categoria" => "Eletronico"
 ];


 $p10 = [
    "nome" => "Creatina Pura 100% Monohidratada 300g Dark Lab | Serve 100 Doses | Mais Alto Grau de Pureza", 
    "foto" => "https://m.media-amazon.com/images/I/81fvQf0EOPL._AC_SX679_.jpg", 
    "preco" => 129.89,
    "descricao" => "Sobre este item     -Melhora o foco que é ideal para estudos     -Promove a recuperação muscular     -Melhora sua resistência nos treinos     -Contribui para a redução da inflamação corporal     -Melhora a força muscular e o desempenho físico     ", 
    "categoria" => "Suplementos"
 ];

 $p11 = [
        "nome" => "EPSON Projetor Powerlite E20, 3400 Lúmens, XGA, HDMI, Branco, Bivolt",
        "foto" => "https://m.media-amazon.com/images/I/61+xdk-uUJL._AC_SX679_.jpg",
        "preco"=> 4.472,
        "descricao" => "Imagens coloridas: 3400 lúmens em branco e em cores         Tecnologia 3LCD de cores até três vezes mais brilhantes para projeções realmente naturais.         resolução nativa XGA e desempenho 4:3.         Lâmpadas duráveis e de baixo custo: até 12.000 horas² no modo econômico.         Conectividade HDMI: Aúdio e vídeo de qualidade HD com um único cabo.", 
        "categoria" => "Informática"

];

$p12= [
    "nome" => "Johnson's Baby Sabonete Líquido Glicerina Da Cabeça Aos Pés, 200ml",
    "foto" => "https://m.media-amazon.com/images/I/61P+myeyCzL._AC_SX679_.jpg",
    "preco" => 19.19,
    "descricao" => "Sua composição ajuda a proteger a barreira natural da pele, proporcionando, assim, o cuidado necessário para a hora do banho; coloque uma pequena quantidade de sabonete nas mãos",
    "categoria" => "Higiene"
];

$p13 = [
   "nome" => "Sofá Omega 2,00m Assento Retrátil e Reclinável Velosuede Grafite - NETSOFAS",
   "foto" => "https://a-static.mlcdn.com.br/800x560/sofa-omega-200m-assento-retratil-e-reclinavel-velosuede-grafite-netsofas/netsofas02/ome250105/9a96d6410a4b648dcd4747ec355f6610.jpeg",
   "preco" =>  1249.97,
   "descricao" => "Informações técnicas:    Material da estrutura:Madeira Maciça de Eucalipto 100% de reflorestamento,produto ecologicamente correto.        Enchimento do Assento:Fibra de Poliéster,Percinta Elástica e Mola Bonnel.        Enchimento do Encosto:Flocos de Espuma e Fibra de Poliéster Siliconada.         Fixação da Estrutura:Grampos galvanizados antiferrugem.         Revestimento / Tecido:Velosuede.        Chaise:Não Possui.        Medidas:         Altura aproximada:100cm (fechado) e 83cm (aberto).        Largura aproximada:200cm.        Profundidade aproximada:95cm (fechado), 135cm (aberto) e 150cm (aberto com encosto reclinado).        Peso aproximado:71kg.        Necessita Montagem:Sim.        Necessita Montador Especializado:Não. Pode ser montado por uma pessoa sozinha.        Capacidade em KG por Lugar:Aproximadamente 80kg.        Garantia:3 meses contra defeito de fabricação. *a contar da data do recebimento da mercadoria.        Limpeza:Aspirar o Produto para Eliminar a Poeira, utilizar um pano levemente umedecido com água e sabão neutro, seguido de pano seco. Não limpar com escovas ou produtos abrasivos.         Recomendações de Manutenção:Usar em local seco, não molhar. Evitar exposição ao sol, para que o produto não sofra alterações na tonalidade.", 
   "categoria" =>  "Móveis De Casa"
];

$p14 = [
    "nome" => "Air pods",
    "foto" => "https://m.media-amazon.com/images/I/7120GgUKj3L._AC_SX679_.jpg",
    "preco" => 1143,
    "descricao" => "Sobre este item         Ajuste universal para conforto durante todo o dia         Ativação e ligação automáticas         Configuração simples em todos os dispositivos Apple         Controle música e chamadas a partir dos seus AirPods         Partilhe facilmente áudio entre dois pares de AirPods no iPhone, iPad, iPod touch ou Apple TV",        
    "categoria" => "Eletronico" 
];


$p15 = [
    "nome" => "Petisco Funcional Para Gatos Whiskas Temptations Pelo Saudável Adultos 40g",
    "foto" => "https://m.media-amazon.com/images/I/61IPHCXcgNL._AC_SX679_.jpg",
    "preco" => 9.89,
    "descricao" => "Petisco crocante com delicioso recheio,
    Vitaminas e minerais balanceados para pelos macios e brilhantes,
    Irresistível e saboroso,
    Demonstração de carinho e conexão com o seu gato",
    "categoria" => "Petiscos para gatos"
 ];

$p16 = [
    "nome" => "A Mandíbula de Caim",
    "foto" => "https://m.media-amazon.com/images/I/51swWSZSBDL._SX296_BO1,204,203,200_.jpg",
    "preco" => 39.90,
    "descricao" => "O leitor precisará identificar seis assassinatos distribuídos em 100 páginas impressas em ordem totalmente aleatória. Existem milhões de combinações possíveis, mas apenas uma é a sequência correta. Com muita lógica e uma leitura perspicaz, pode-se organizá-las na progressão certa, de modo que se revelem seis vítimas de assassinato e seus respectivos algozes. O quebra-cabeça é extremamente difícil, a solução do problema permanece em segredo e até hoje apenas três pessoas conseguiram decifrar o enigma.",
    "categoria" => "Livro"
];

$p17 = [
    "nome" => "Cerveja",
    "foto" => "https://down-br.img.susercontent.com/file/sg-11134201-22110-vmm1jxstfijve5",
    "preco" => 33.47,
    "descricao" => "Calças      UNISSEX            FEITO É POLIÉSTER TECTEL     POSSUI ELÁSTICO NA CINTURA E NAS BARRAS PARA AJUSTAR MELHOR AO CORPO, VESTINDO MELHOR DIVERSOS TAMANHOS, TECIDO DE ALTA QUALIDADE.          TAMANHOS     PP VESTE DO 34 AO 38     P VESTE DO 36 AO 40     M VESTE DO 38 AO 42     G VESTE DO 40 AO 44     GG VESTE DO 42 AO 46          GG comprimento 111 cm cintura 95 cm     G comprimento 110 cm cintura 94 cm     M comprimento 107 cm cintura 92 cm     P comprimento 105 cm cintura 90 cm     PP comprimento 102 cm cintura 88 cm          Tamanho 16 anos Comprimento 97 cm cintura 82 cm           Tamanho 14 anos Comprimento 96 cm cintura 79 cm          Tamanho 12 anos Comprimento 94 cm cintura 76 cm           Tamanho 10 anos Comprimento 91 cm cintura 70cm      ",
    "categoria" => "Moda"
 ];

 $p18 = [
    "nome" => "KOOYNN Fantasia inflável de dinossauro T-REX para adultos",
    "foto" => "https://m.media-amazon.com/images/I/610JnI2AV9L._AC_SX569_.jpg",
    "preco" => 209.99,
    "descricao" => "Fantasia engraçada de dinossauro/unicórnio inflável, chama a atenção e risadas para você.",
    "categoria" => "Moda"
 ];

$p19 = [
      "nome" => "Óculos de sol Maui Jim World Cup",
      "foto" => "https://m.media-amazon.com/images/I/41VR8IQfWeL._AC_SX679_.jpg",
      "preco" => 1614.47,
      "descricao" => "Todos os óculos de sol Maui Jim têm a tecnologia de lente PolarizedPlus2 que vai além de proteger seus olhos do brilho e dos raios UV nocivos, aprimorando as cores para revelar a verdadeira beleza do mundo ao seu redor",
      "categoria" => "Moda"
   ];

$produtos = [$p1, $p2, $p3, $p4, $p5, $p6, $p7, $p8, $p9, $p10, $p11, $p12, $p13, $p14, $p15, $p16, $p17, $p18, $p19];

?>