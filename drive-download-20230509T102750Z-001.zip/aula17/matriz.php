<?php
   
$v1 = [
    "Placa" => "AAA-0001",
    "Nome"  => "Fusca",
    "Ano"   => 1970,
    "Valor" => 30000
];

$v2 = [
    "Placa" => "BBB-0002",
    "Nome"  => "Gol",
    "Ano"   => 2014,
    "Valor" => 45000
];

$v3 = [
    "Placa" => "CCC-0003",
    "Nome"  => "Onix",
    "Ano"   => 2020,
    "Valor" => 70000
];

$veiculos = [$v1, $v2, $v3];